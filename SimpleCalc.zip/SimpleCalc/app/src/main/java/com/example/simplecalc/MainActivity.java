package com.example.simplecalc;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    EditText et1, et2;
    Button buttonTambah, buttonKurang, buttonKali, buttonBagi;
    TextView txthasil;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        et1=(EditText) findViewById(R.id.bilangan1);
        et2=(EditText) findViewById(R.id.bilangan2);
        txthasil=(TextView) findViewById(R.id.tvhasil);
        buttonTambah=(Button) findViewById(R.id.btTambah);
        buttonKurang=(Button) findViewById(R.id.btKurang);
        buttonKali=(Button) findViewById(R.id.btKali);
        buttonBagi=(Button) findViewById(R.id.btBagi);

        buttonTambah.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double bil1, bil2, hasil;
                bil1=Double.parseDouble(et1.getText().toString().trim());
                bil2=Double.parseDouble(et2.getText().toString().trim());
                hasil=bil1+bil2;
                String hasil1=String.valueOf(hasil);
                txthasil.setText(hasil1);
            }
        });

        buttonKurang.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double bil1, bil2, hasil;
                bil1=Double.parseDouble(et1.getText().toString().trim());
                bil2=Double.parseDouble(et2.getText().toString().trim());
                hasil=bil1-bil2;
                String hasil1=String.valueOf(hasil);
                txthasil.setText(hasil1);
            }
        });

        buttonKali.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double bil1, bil2, hasil;
                bil1=Double.parseDouble(et1.getText().toString().trim());
                bil2=Double.parseDouble(et2.getText().toString().trim());
                hasil=bil1*bil2;
                String hasil1=String.valueOf(hasil);
                txthasil.setText(hasil1);
            }
        });

        buttonBagi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double bil1, bil2, hasil;
                bil1=Double.parseDouble(et1.getText().toString().trim());
                bil2=Double.parseDouble(et2.getText().toString().trim());
                hasil=bil1/bil2;
                String hasil1=String.valueOf(hasil);
                txthasil.setText(hasil1);


            }
        });
    }
}